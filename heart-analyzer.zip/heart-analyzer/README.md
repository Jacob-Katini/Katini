# Heart Disease Analyzer

## Project Description
The Heart Disease Analyzer is a digital consultant platform designed to assist users in identifying potential heart conditions based on general symptoms. The system emphasizes natural remedies, lifestyle adjustments, and dietary plans to counter identified risks.

## Features
- **User Authentication:** Secure patient accounts with hashed passwords.
- **Symptom Matching:** A backend algorithm that compares user input against a database of known heart diseases.
- **Holistic Recommendations:** Provides natural medication alternatives, specific diet plans, and lifestyle tips.
- **Patient History:** Maintains a secure log of all previous diagnoses and recommendations for each user.

## Technical Stack
- **Frontend:** HTML5, CSS3 (Light Blue & White theme), JavaScript.
- **Backend:** PHP.
- **Database:** MySQL / SQL.
- **Server:** XAMPP (Apache).
- **Editor:** VS Code.

## Database Structure
The project utilizes a database named `heart_disease_db` with three core tables:
1. `users`: Stores login credentials.
2. `diseases`: Contains the knowledge base of symptoms and treatments.
3. `patient_history`: Tracks interactions between users and the analyzer.

## How to Install and Run
1. Copy the `heart-analyzer` folder to your XAMPP `htdocs` directory.
2. Open **phpMyAdmin** and create a database named `heart_disease_db`.
3. Import the `sql/database.sql` and `sql/insert_data.sql` files.
4. Access the system via `http://localhost/heart-analyzer`.

## Disclaimer
This project is for educational purposes only. It is not a substitute for professional medical advice, diagnosis, or treatment.
