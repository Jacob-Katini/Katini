<?php 
session_start(); 
if (!isset($_SESSION['last_result'])) { header("Location: analyzer.php"); exit(); }
$data = $_SESSION['last_result'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Analysis Results</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .result-box { border-bottom: 1px solid #CFE9FF; padding: 10px 0; }
        .label { font-weight: bold; color: #3AA0FF; display: block; }
    </style>
</head>
<body>
    <div class="container" style="width: 600px;">
        <h2>Analysis Result</h2>
        
        <div class="result-box">
            <span class="label">Potential Condition:</span>
            <p><?php echo $data['disease_name']; ?></p>
        </div>

        <div class="result-box">
            <span class="label">Natural Medication:</span>
            <p><?php echo $data['natural_medication']; ?></p>
        </div>

        <div class="result-box">
            <span class="label">Recommended Diet:</span>
            <p><?php echo $data['diet_plan']; ?></p>
        </div>

        <div class="result-box">
            <span class="label">Lifestyle Changes:</span>
            <p><?php echo $data['lifestyle_tips']; ?></p>
        </div>

        <p style="font-size: 11px; color: grey; margin-top: 20px;">
            Note: This system is for educational purposes. Consult a professional doctor for medical diagnosis.
        </p>
        
        <button onclick="window.location.href='analyzer.php'">New Analysis</button>
        <button onclick="window.location.href='history.php'" style="background: none; color: #3AA0FF; margin-top: 10px;">View History</button>
    </div>
</body>
</html>
