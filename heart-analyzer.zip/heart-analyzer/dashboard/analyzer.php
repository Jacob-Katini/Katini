<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Symptom Checklist</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container" style="width: 500px;">
        <h2>Select Your Symptoms</h2>
        <form action="../php/process_diagnosis.php" method="POST">
            <label class="symptom-item"><input type="checkbox" name="symptoms[]" value="Headache"> Headache</label>
            <label class="symptom-item"><input type="checkbox" name="symptoms[]" value="Shortness of breath"> Shortness of breath</label>
            <label class="symptom-item"><input type="checkbox" name="symptoms[]" value="Nosebleed"> Nosebleed</label>
            <label class="symptom-item"><input type="checkbox" name="symptoms[]" value="Chest pain"> Chest pain</label>
            <label class="symptom-item"><input type="checkbox" name="symptoms[]" value="Fatigue"> Fatigue</label>
            <label class="symptom-item"><input type="checkbox" name="symptoms[]" value="Dizziness"> Dizziness</label>
            
            <button type="submit" style="margin-top:20px;">Analyze Symptoms</button>
        </form>
    </div>
</body>
</html>
