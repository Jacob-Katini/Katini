<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch all previous interactions for this user joining the history and diseases tables
$query = "SELECT h.diagnosis_date, d.disease_name, d.natural_medication, d.lifestyle_tips, d.diet_plan 
          FROM patient_history h 
          JOIN diseases d ON h.disease_id = d.id 
          WHERE h.user_id = ? 
          ORDER BY h.diagnosis_date DESC";

$stmt = $pdo->prepare($query);
$stmt->execute([$user_id]);
$history = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Medical History</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .history-card {
            border: 1px solid #CFE9FF;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            font-size: 14px;
        }
        .date-tag {
            font-size: 12px;
            color: #777;
            display: block;
            margin-bottom: 5px;
        }
        .disease-title {
            font-weight: bold;
            color: #3AA0FF;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="container" style="width: 700px; height: auto; max-height: 80vh; overflow-y: auto;">
        <h2>Your Consultation History</h2>
        
        <?php if (empty($history)): ?>
            <p style="text-align:center;">No previous records found.</p>
        <?php else: ?>
            <?php foreach ($history as $row): ?>
                <div class="history-card">
                    <span class="date-tag">Date: <?php echo date('F j, Y, g:i a', strtotime($row['diagnosis_date'])); ?></span>
                    <div class="disease-title"><?php echo $row['disease_name']; ?></div>
                    <p><strong>Natural Meds:</strong> <?php echo $row['natural_medication']; ?></p>
                    <p><strong>Diet & Lifestyle:</strong> <?php echo $row['diet_plan']; ?> | <?php echo $row['lifestyle_tips']; ?></p>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <button onclick="window.location.href='index.php'">Back to Dashboard</button>
    </div>
</body>
</html>
