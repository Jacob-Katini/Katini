<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Patient Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <h2>Welcome, <?php echo $_SESSION['username']; ?></h2>
        <p style="text-align:center;">Select an option to proceed</p>
        
        <button onclick="window.location.href='analyzer.php'" style="margin-bottom: 10px;">New Heart Analysis</button>
        <button onclick="window.location.href='history.php'" style="background-color: white; color: #3AA0FF; border: 1px solid #3AA0FF;">View My History</button>
        
        <p style="text-align:center; margin-top:20px;">
            <a href="../php/logout.php" style="color: red; text-decoration: none; font-size: 14px;">Logout</a>
        </p>
    </div>
</body>
</html>
