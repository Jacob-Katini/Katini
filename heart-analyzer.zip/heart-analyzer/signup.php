<!DOCTYPE html>
<html>
<head>
    <title>Heart Disease Analyzer - Sign Up</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <h2>Create Account</h2>
        <form action="php/auth_signup.php" method="POST">
            <input type="text" name="username" placeholder="Choose Username" required>
            <input type="password" name="password" placeholder="Choose Password" required>
            <button type="submit">Register</button>
        </form>
        <p style="text-align:center; font-size:12px;">
            Already have an account? <a href="index.php">Login</a>
        </p>
    </div>
</body>
</html>
