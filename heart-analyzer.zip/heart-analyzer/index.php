<!DOCTYPE html>
<html>
<head>
    <title>Heart Disease Analyzer - Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <h2>Heart Disease Analyzer</h2>
        <form action="php/auth_login.php" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login to Account</button>
        </form>
        <p style="text-align:center; font-size:12px;">
            Don't have an account? <a href="signup.php">Sign Up</a>
        </p>
    </div>
</body>
</html>
