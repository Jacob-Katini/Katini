<?php
session_start();
require_once '../config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['symptoms'])) {
    $selected_symptoms = $_POST['symptoms']; // Array from checkboxes
    $all_diseases = $pdo->query("SELECT * FROM diseases")->fetchAll();
    
    $best_match = null;
    $max_score = 0;

    foreach ($all_diseases as $disease) {
        $db_symptoms = explode(', ', $disease['symptoms_list']);
        $matches = count(array_intersect($selected_symptoms, $db_symptoms));

        if ($matches > $max_score) {
            $max_score = $matches;
            $best_match = $disease;
        }
    }

    if ($best_match) {
        // Save to History
        $stmt = $pdo->prepare("INSERT INTO patient_history (user_id, disease_id) VALUES (?, ?)");
        $stmt->execute([$_SESSION['user_id'], $best_match['id']]);
        
        // Redirect to results
        $_SESSION['last_result'] = $best_match;
        header("Location: ../dashboard/results.php");
    } else {
        echo "No specific match found. Please consult a doctor.";
    }
}
?>
